
document.querySelector('.login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert("Logged in! Compete in the hackathon.");
});
